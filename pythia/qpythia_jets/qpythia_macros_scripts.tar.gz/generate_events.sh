#!/bin/bash

# . /project/alice/alisoft/scripts/setAlice.sh  -v LastAN
. /project/alice/alicesw/bin/alice-env.sh -n 1

cd $PBS_O_WORKDIR

pthardmin=${PTHARDMIN:-0}
pthardmax=${PTHARDMAX:-1000}
qhat=${QHAT:-50}  # qhat in 0.1 GeV^2/fm
sqrts=${SQRTS:-2760}
outdir=${OUTDIR:-$JOB_ID}

while [ $# -gt 1 ]
do
  case $1
  in
    --pthardmin)
      shift
      pthardmin=$1
      ;;
    --pthardmax)
      shift
      pthardmax=$1
      ;;
    *)
      echo "Unknown option: $1"
      echo "Usage: $0 [--pthardmin xx] [--pthardmax xx]"
  esac
  shift
done

basedir=output/events_${pthardmin}_${pthardmax}_${qhat}
if [ ! -d $basedir ]
then 
  mkdir $basedir
fi


if [ -d $basedir/$outdir ]
then
  print "Output directory $outdir already exists; quitting"
  exit 255
fi

mkdir $basedir/$outdir
cp runqPythia.C $basedir/$outdir
cd $basedir/$outdir

aliroot -b -q runqPythia.C\(1000,$pthardmin,$pthardmax,$qhat,$sqrts\)


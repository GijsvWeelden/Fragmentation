
sqrts=2760
qhat=50
# fname="pythia_full_jet_ff"
fname="pythia_charged_jet_spectra"
# fname="pythia_full_jet_spectra"

hadd -f ${fname}_${sqrts}GeV_5_15_${qhat}_all.root ${fname}_${sqrts}GeV_5_15_${qhat}_[0-9]*.root
hadd -f ${fname}_${sqrts}GeV_15_25_${qhat}_all.root ${fname}_${sqrts}GeV_15_25_${qhat}_[0-9]*.root
hadd -f ${fname}_${sqrts}GeV_25_40_${qhat}_all.root ${fname}_${sqrts}GeV_25_40_${qhat}_[0-9]*.root
hadd -f ${fname}_${sqrts}GeV_40_100_${qhat}_all.root ${fname}_${sqrts}GeV_40_100_${qhat}_[0-9]*.root
hadd -f ${fname}_${sqrts}GeV_100_250_${qhat}_all.root ${fname}_${sqrts}GeV_100_250_${qhat}_[0-9]*.root


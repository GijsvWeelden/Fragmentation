#!/bin/bash

# Use bash shell on SGE
#$ -S /bin/bash
#
# Use current working directory
#$ -cwd

# . /project/alice/alisoft/scripts/setAlice.sh  -v LastAN

ALICE_ENV_DONT_CHANGE_PS1=1

. /project/alice/alicesw/bin/alice-env.sh -n 1

pthardmin=${PTHARDMIN:-0}
pthardmax=${PTHARDMAX:-1000}
qhat=${QHAT:-50}  # qhat in 0.1 GeV^2/fm
sqrts=${SQRTS:-2760}

while [ $# -gt 1 ]
do
  case $1
  in
    --pthardmin)
      shift
      pthardmin=$1
      ;;
    --pthardmax)
      shift
      pthardmax=$1
      ;;
    *)
      echo "Unknown option: $1"
      echo "Usage: $0 [--pthardmin xx] [--pthardmax xx]"
  esac
  shift
done

#NB: pthard not used now:
cd $PBS_O_WORKDIR

echo "hostname: $HOSTNAME"

# aliroot -b -q analysePythia.C\(\"output/events_${pthardmin}_${pthardmax}_${qhat}\",\"output/pythia_jets_largeR_${pthardmin}_${pthardmax}_${qhat}.root\"\)
aliroot -b -q runAnalysisPythia.C\(\"output/events_${pthardmin}_${pthardmax}_${qhat}\",\"output/pythia_jet_shapes_largeR_${pthardmin}_${pthardmax}_${qhat}.root\"\)

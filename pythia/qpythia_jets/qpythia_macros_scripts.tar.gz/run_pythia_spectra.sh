. /project/alice/alisoft/scripts/setAlice.sh  -v LastAN

cd $PBS_O_WORKDIR

pthardmin=${PTHARDMIN:-0}
pthardmax=${PTHARDMAX:-1000}
qhat=${QHAT:-50}  # qhat in 0.1 GeV^2/fm
sqrts=${SQRTS:-2760}

while [ $# -gt 1 ]
do
  case $1
  in
    --pthardmin)
      shift
      pthardmin=$1
      ;;
    --pthardmax)
      shift
      pthardmax=$1
      ;;
    *)
      echo "Unknown option: $1"
      echo "Usage: $0 [--pthardmin xx] [--pthardmax xx]"
  esac
  shift
done

jobid=`echo $PBS_JOBID | gawk -F'.' '{print $1}'`

#NB: pthard not used now:

aliroot -b -q pythia6JetSpectra.C\(50000,\"output/pythia_charged_jet_spectra_${sqrts}GeV_${pthardmin}_${pthardmax}_${qhat}_${jobid}.root\",$pthardmin,$pthardmax,$qhat,$sqrts\)


# sqrts=13000
# sqrts=5020
qhat=0
qsub -q stbcq -e log/ -o log/ -v PTHARDMIN=5,PTHARDMAX=15,QHAT=$qhat run_analysis.sh
qsub -q stbcq -e log/ -o log/ -v PTHARDMIN=15,PTHARDMAX=25,QHAT=$qhat run_analysis.sh
qsub -q stbcq -e log/ -o log/ -v PTHARDMIN=25,PTHARDMAX=40,QHAT=$qhat run_analysis.sh
qsub -q stbcq -e log -o log -v PTHARDMIN=40,PTHARDMAX=80,QHAT=$qhat run_analysis.sh
qsub -q stbcq -e log -o log -v PTHARDMIN=80,PTHARDMAX=120,QHAT=$qhat run_analysis.sh
qsub -q stbcq -e log -o log -v PTHARDMIN=120,PTHARDMAX=250,QHAT=$qhat run_analysis.sh

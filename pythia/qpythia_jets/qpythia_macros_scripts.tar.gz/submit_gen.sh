# sqrts=13000
# sqrts=5020
if [ $# -lt 1 ]
then
  echo "Need to specify job number"
  exit 255
fi
qhat=50
batch_num=$1
outdir=`printf "%05d" $batch_num`
echo $outdir
qsub -q stbcq -e log -o log -v PTHARDMIN=5,PTHARDMAX=15,QHAT=$qhat,OUTDIR=$outdir generate_events.sh
qsub -q stbcq -e log -o log -v PTHARDMIN=15,PTHARDMAX=25,QHAT=$qhat,OUTDIR=$outdir generate_events.sh
qsub -q stbcq -e log -o log -v PTHARDMIN=25,PTHARDMAX=40,QHAT=$qhat,OUTDIR=$outdir generate_events.sh
qsub -q stbcq -e log -o log -v PTHARDMIN=40,PTHARDMAX=80,QHAT=$qhat,OUTDIR=$outdir generate_events.sh
qsub -q stbcq -e log -o log -v PTHARDMIN=80,PTHARDMAX=120,QHAT=$qhat,OUTDIR=$outdir generate_events.sh
qsub -q stbcq -e log -o log -v PTHARDMIN=120,PTHARDMAX=250,QHAT=$qhat,OUTDIR=$outdir generate_events.sh
